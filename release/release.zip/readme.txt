Just try and beat it!

To play make sure you place both UndefeatedTicTacToe.dll
and UndefeatedTicTacToe.exe in the same directory.
Then double click the exe to run.

Enjoy!